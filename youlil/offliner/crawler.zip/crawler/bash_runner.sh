#!/bin/bash
. ~/.bash_profile 

python ./run_spider.py
